
public  class Cliente {

	// Trocou-se Integer por int
	public int agencia;

	public int conta;

	public String cpf;

	public String nome ;

	public String nascimento;

	public String endereco ;

	public String telefone;
	
	//Trocou-se Float float
	public float saldo ;

	public String senha ;

	public  void MostrarCliente() {
		System.out.println("Ag�ncia:"+ agencia);
	

	}

}
