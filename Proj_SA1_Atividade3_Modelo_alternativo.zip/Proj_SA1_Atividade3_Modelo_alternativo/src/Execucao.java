
public class Execucao {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Cliente cl1=new Cliente();
		cl1.agencia = 100;
		cl1.conta = 34567;
		cl1.nome = "Jos� da Silva";
		cl1.nome="Rolfi";
		
		System.out.println("Ag�ncia:" + cl1.agencia);
		System.out.println("Conta:" +cl1.conta);
	    System.out.println("Nome:"+cl1.nome);
	    
	    

	}

}
